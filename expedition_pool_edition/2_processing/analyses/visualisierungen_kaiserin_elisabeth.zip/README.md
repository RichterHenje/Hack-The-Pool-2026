# Visualisierungen Kaiserin Elisabeth

Stand 28.10.2026. Drei Seiten und ein SVG, alle mit denselben Design-Tokens.

## Dateien

| Datei | Inhalt |
| --- | --- |
| `html/01_datenfluss_data-cleaning.html` | Workflow des Data-Cleaning-Teams (englisch) mit Kartenausschnitt |
| `html/02_workflow_interface-team.html` | Workflow des Interface-Teams (englisch) |
| `html/03_jagdsaetze_tiere.html` | Tierarten und zeitlicher Verlauf der Jagdsätze (deutsch) |
| `svg/datenfluss_kaiserin_elisabeth.svg` | Workflow des Data-Cleaning-Teams als eigenständiges SVG (fester heller Hintergrund, kein Dark Mode) |
| `tokens.css` | Farben und Schriften aller Seiten an einer Stelle |
| `scripts/` | Python-Skripte, die den Kartenausschnitt und die Tier-Diagramme aus den Repo-Daten erzeugen |

## Design anpassen

1. Die HTML-Dateien enthalten die Werte aus `tokens.css` im `:root`-Block am Anfang des `<style>`. Dort Farben und Schriften ersetzen. Alle Elemente ziehen ihre Farben aus diesen Variablen, einschließlich Dark Mode.
2. Schriften: Fraunces (Titel) und IBM Plex Sans (Text) kommen von Google Fonts. Ohne Internet greifen Georgia und Segoe UI.
3. Das SVG hat die Farben fest im `<style>`-Block. Dort dieselben Werte eintragen.
4. Die Seiten sind für Artefakt-Ansicht gebaut (ohne `<html>`-Gerüst). Zum Öffnen im Browser vorne `<!doctype html><html lang="de"><head><meta charset="utf-8">` und hinten `</body></html>` ergänzen und `<main>` in `<body>` setzen.

## Daten

- Tier-Diagramme: `Kriegsmarine/kaiserin_elisabeth/prototype/data/ke_diary.json`. Gezählt werden Sätze mit „erlegen“ oder „schießen“ und die darin genannten Tierarten, keine Stückzahlen. Die Texterkennung ist ungeprüft.
- Kartenausschnitt: `prototype/arcgis/ke_routes.geojson`, `ke_stops.geojson` und Küstenlinie `prototype/data/world.js` (Natural Earth).

## Skripte

`scripts/mapgen.py` und `scripts/tiere.py` lesen die Daten aus dem Repo (Pfade oben in der Datei anpassen). `tiere.py` braucht `tiere_tpl.html`, `build.py` und `tpl.html` sind die Vorlagen des Datenfluss-Diagramms.
