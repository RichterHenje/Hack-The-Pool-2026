import os, re, sys
d = os.path.dirname(os.path.abspath(__file__))
html = open(os.path.join(d, "datenfluss.html"), encoding="utf-8").read()
m = re.search(r"<svg[^>]*>(.*)</svg>", html, re.S)
inner = m.group(1).replace('style="color: var(--ink)"', 'color="#14283b"')
inner = inner.replace('color="#14283b"', 'style="color:#14283b"')
css = """
  text { font-family: "IBM Plex Sans", "Segoe UI", Arial, sans-serif; }
  .col { font-size: 11px; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; fill: #586b7c; }
  .src { fill: none; stroke: #9db0bf; stroke-width: 1.5; }
  .step { fill: #dfe9f0; stroke: none; }
  .sep { stroke: #9db0bf; stroke-width: 1; }
  .review { fill: none; stroke: #a8680f; stroke-width: 1.5; stroke-dasharray: 6 4; }
  .t { font-size: 13px; font-weight: 600; fill: #14283b; }
  .s { font-size: 11px; font-weight: 400; fill: #586b7c; }
  .t-rev { font-size: 12px; font-weight: 600; fill: #a8680f; }
  .flow { fill: none; stroke: #14283b; stroke-width: 1.4; }
  .sea { fill: #f2f5f7; }
  .land { fill: #c4d3de; stroke: none; }
  .route { fill: none; stroke: #a8680f; stroke-width: 1.6; stroke-linejoin: round; }
  .dot circle { fill: #14283b; }
  .frame { fill: none; stroke: #14283b; stroke-width: 1.5; }
"""
title = "Workflow: Data Cleaning and Enrichment"
out = ('<?xml version="1.0" encoding="UTF-8"?>\n'
       '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1270 524" width="1270" height="524" role="img">\n'
       f'<title>{title}</title>\n<style>{css}</style>\n'
       '<rect width="1270" height="524" fill="#f2f5f7" />\n'
       f'<text x="20" y="30" style="font-family:Georgia,serif;font-size:20px;font-weight:600;fill:#14283b">{title}</text>\n'
       + '<g transform="translate(0 44)">' + inner + '</g>' + '\n</svg>\n')
open(sys.argv[1], "w", encoding="utf-8").write(out)
print(len(out))
